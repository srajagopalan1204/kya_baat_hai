# Workflow SRO
**Purpose:** Describe end-to-end workflow for SRO.  
**Scope:** Applies to Tech Mobile / Service.  
**Prereqs:** Access to tools; correct role.  
**Status:** Draft • **Owner:** <role/name> • **Last Reviewed:** YYYY-MM-DD

## Steps
1. …
2. …

## Rollback / Recovery
- …

## References
- UAP: <link> • Twine: <passage> • PPT: <path> • Code: <file>

---

## Revision History
| Date | Change | By | PR |
|---|---|---|---|
