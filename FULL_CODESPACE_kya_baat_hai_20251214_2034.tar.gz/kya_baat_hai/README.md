# kya_baat_hai
## Docs
- See [docs/SOPs/00_Index.md](docs/SOPs/00_Index.md)

cp /workspaces/kya_baat_hai/Root/Chk_Lst/src/checklist_builder.py /workspaces/kya_baat_hai/Root/Chk_Lst/src/Prev/checklist_builder_251114_1639.py


python "/workspaces/kya_baat_hai/Root/Chk_Lst/src/checklist_builder_4e.py" \
      --spec "/workspaces/kya_baat_hai/Root/Chk_Lst/specs/Checklist_TaskType_EDXBuild_Quo2Ord_v4f_251116.xlsx" \
      --template "/workspaces/kya_baat_hai/Root/Chk_Lst/templates/SOP_Build_Checklist_template_v4f.html" \
      --out-html /workspaces/kya_baat_hai/Root/Chk_Lst/rep_checklists/EdxlBuild_V4f_Checklist.html